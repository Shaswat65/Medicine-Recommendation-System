from flask import Flask, render_template, request
import pandas as pd
import google.generativeai as genai
import markdown
import os

app = Flask(__name__)

with open("api.txt", "r") as api:
    os.environ["GOOGLE_API_KEY"] = api.read().strip()
genai.configure(api_key=os.environ["GOOGLE_API_KEY"])

model = genai.GenerativeModel(
    model_name="gemini-2.5-flash",
    generation_config={
        "response_mime_type": "text/plain"
    } 
)

CSV_PATH = "C:/Users/shasw/Desktop/miniproject2/combined_output.csv"   
df = pd.read_csv(CSV_PATH)
data_preview = df.head().to_string()

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        query = request.form["query"]

        if not query:
            return render_template("index.html", error="Please describe your symptoms.")

        prompt = f"""
        You are a medical recommendation assistant.
        IMPORTANT:
        - Respond ONLY in Markdown.
        - DO NOT return any HTML tags.
        - Use **bold**, bullet points, headings, dosage, and clean formatting.

        Dataset sample:
        {data_preview}

        User problem:
        "{query}"

        Recommend the best medicine(s) with dosage and explanation.
        """

        response = model.generate_content(prompt)

        recommendation_html = markdown.markdown(response.text)

        return render_template("result.html", recommendation=recommendation_html)

    return render_template("index.html")
    
if __name__ == "__main__":
    app.run(debug=True)
